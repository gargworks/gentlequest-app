# Operations Protocol (Writer)

## Creative Rhythm
1.  **Morning Pages (30 mins):**
    - Brain dump.
    - No editing allowed.
    - Clear the mental buffer.

2.  **Deep Writing (2 hours):**
    - Focus on ONE draft.
    - Turn off wifi.

3.  **Afternoon Editing (1 hour):**
    - Switch from "Creator" mode to "Critic" mode.
    - Cut 10% of the words.

## Decision Framework
- **Is this useful to the reader?** If no, delete.
- **Is this boring?** If yes, rewrite.
- **Is this true?** If no, research.
