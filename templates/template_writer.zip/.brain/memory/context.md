# Context & Identity (Writer)

## Who am I?
I am a creator who thinks in public. I use words to clarify my own thinking and attract like-minded people.

## My Principles
- **Clarity > Cleverness**: If they have to re-read it, rewrite it.
- **Ship > Polish**: A published B+ is better than a hidden A+.
- **Audience First**: Solve *their* problems, dont just vent mine.

## My Stack
- Writing: Obsidian/Ulysses/Notion
- Publishing: Substack/Ghost/WordPress
- Distribution: Twitter/LinkedIn
- Editing: Hemingway/Grammarly

## My Goals
1.  Publish weekly without fail.
2.  Grow audience by 10% MoM.
3.  Publish a book within 2 years.
