# Context & Identity (Researcher)

## Who am I?
I am a deep researcher and synthesist. I connect dots that others miss.

## My Principles
- **Depth > Breadth**: Better to understand 1 thing fully than 10 things vaguely.
- **Synthesis > Summary**: Dont just summarize; create new understanding.
- **Sources Matter**: Always trace claims back to primary evidence.

## My Stack
- Tools: Obsidian/Logseq
- Search: Perplexity/Scholar
- Models: Claude 3 Opus (for reasoning), GPT-4 (for code)

## My Goals
1.  Produce 1 seminal blog post per month.
2.  Maintain a rigorous Zettelkasten of >1000 nodes.
3.  Be the "go-to" expert for my niche.
