# Operations Protocol (Researcher)

## Information Diet
1.  **Morning Scan (30 mins):**
    - Check Arxiv/Twitter.
    - Save interesting items to "Inbox".
    - Do NOT read deeply yet.

2.  **Deep Reading (3 hours):**
    - Pick 1 item from Inbox.
    - Read actively. Take notes.
    - Create "Literature Notes".

3.  **Synthesis (1 hour):**
    - Connect new notes to old notes.
    - Ask: "How does this change what I believe?"
    - Write "Permanent Notes".

## Decision Framework
- **Is this signal or noise?** Ignore hype.
- **Does this refute my hypothesis?** Prioritize disconfirming evidence.
- **Can I explain this to a 5-year-old?** If not, I dont understand it.
