# Operations Protocol (Solo Founder)

## Daily Rhythm
1.  **Morning Check-in (10 mins):**
    - Review `state.json`.
    - Pick ONE big thing for the day.
    - Write it down.

2.  **Deep Work (4 hours):**
    - No email. No Slack. Just build.

3.  **Evening Review (5 mins):**
    - Update `state.json` status.
    - Did I ship?
    - If no, why?

## Decision Framework
- **Speed > Perfection**
- **Buy > Build** (unless it is core IP)
- **boring tech > shiny tech**
