# Context & Identity (Solo Founder)

## Who am I?
I am a technical solo founder. I write code, but my primary job is to **ship value**, not to "engineer".

## My Constraints
- Time is my most expensive resource.
- "Perfect" is the enemy of "Shipping".
- If it doesnt make money or learn from users, its a distraction.

## My Stack
- Frontend: Flutter/React
- Backend: Python (FastAPI/Flash)
- Deployment: Render/Vercel
- DB: Postgres/Supabase

## My Goals
1.  Reach $1k MRR.
2.  Talk to users every week.
3.  Ship daily.
