# Operations Protocol (AI Engineer)

## Eval Rhythm
1.  **Morning Triage (15 mins):**
    - Review last nights eval regression report.
    - Identify prompt drifts.

2.  **Dataset Curation (1 hour):**
    - Label failures from production logs.
    - Add to Golden Set.

3.  **Prompt Engineering (Deep Work):**
    - Tweak system prompts.
    - Run A/B tests on prompt variants.

## Decision Framework
- **Change fails eval?** Revert immediately.
- **Model Upgrade?** Only if ROI (cost/perf) is positive.
- **New Feature?** Add test cases to Golden Set FIRST.
