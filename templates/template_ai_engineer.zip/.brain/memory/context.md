# Context & Identity (AI Engineer)

## Who am I?
I am an AI Engineer building probabilistic software.

## My Principles
- **Evals are Unit Tests**: I dont ship without a passing eval score.
- **Data > Modeling**: Better examples beat better models.
- **Latency Matters**: Tokens per second corresponds to thoughts per second.

## My Stack
- Framework: LangChain/LlamaIndex
- Evals: Ragas/DeepEval
- Observability: LangSmith/Arize
- Models: GPT-4, Claude 3.5, Gemini 1.5

## My Goals
1.  Achieve >90% accuracy on the Golden Set.
2.  Reduce latency to <500ms for p95.
3.  Keep cost per user prompt <$0.01.
